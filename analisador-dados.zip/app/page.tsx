"use client"

import { useState } from "react"
import { FileUpload } from "@/components/file-upload"
import { DataTable } from "@/components/data-table"
import { VariableFilter } from "@/components/variable-filter"
import { VariableClassification } from "@/components/variable-classification"
import { StatisticsPanel } from "@/components/statistics-panel"
import { ChartsPanel } from "@/components/charts-panel"
import { ReportDialog } from "@/components/report-dialog"
import { BarChart3 } from "lucide-react"
import { classifyDataset, type VariableInfo, type VariableType } from "@/lib/variable-classifier"
import { calculateDatasetStatistics, type VariableStatistics } from "@/lib/statistics"

export default function Home() {
  const [data, setData] = useState<any[]>([])
  const [columns, setColumns] = useState<string[]>([])
  const [fileName, setFileName] = useState<string>("")
  const [classifications, setClassifications] = useState<Map<string, VariableInfo>>(new Map())
  const [statistics, setStatistics] = useState<Map<string, VariableStatistics>>(new Map())
  const [selectedTypes, setSelectedTypes] = useState<Set<VariableType>>(new Set())

  const handleDataLoaded = (parsedData: any[], cols: string[], name: string) => {
    setData(parsedData)
    setColumns(cols)
    setFileName(name)

    const classified = classifyDataset(parsedData, cols)
    setClassifications(classified)

    const stats = calculateDatasetStatistics(parsedData, classified)
    setStatistics(stats)

    const allTypes = new Set(Array.from(classified.values()).map((v) => v.type))
    setSelectedTypes(allTypes)
  }

  const filteredClassifications = new Map(
    Array.from(classifications.entries()).filter(([_, info]) => selectedTypes.has(info.type)),
  )

  const filteredStatistics = new Map(
    Array.from(statistics.entries()).filter(([col, _]) => {
      const info = classifications.get(col)
      return info && selectedTypes.has(info.type)
    }),
  )

  const typeCounts = Array.from(classifications.values()).reduce(
    (acc, info) => {
      acc[info.type] = (acc[info.type] || 0) + 1
      return acc
    },
    {} as Record<VariableType, number>,
  )

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary">
                <BarChart3 className="h-6 w-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-xl font-semibold text-foreground">Analisador de Dados</h1>
                <p className="text-sm text-muted-foreground">Análise estatística completa</p>
              </div>
            </div>
            {data.length > 0 && (
              <ReportDialog fileName={fileName} data={data} classifications={classifications} statistics={statistics} />
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {data.length === 0 ? (
          <div className="flex min-h-[600px] items-center justify-center">
            <FileUpload onDataLoaded={handleDataLoaded} />
          </div>
        ) : (
          <div className="space-y-6">
            {/* File Info */}
            <div className="flex items-center justify-between rounded-lg border border-border bg-card p-4">
              <div>
                <p className="text-sm text-muted-foreground">Arquivo carregado</p>
                <p className="font-mono text-sm font-medium text-foreground">{fileName}</p>
              </div>
              <div className="text-right">
                <p className="text-sm text-muted-foreground">Registros</p>
                <p className="text-2xl font-semibold text-foreground">{data.length.toLocaleString()}</p>
              </div>
            </div>

            {/* Data Table */}
            <DataTable data={data} columns={columns} />

            <VariableFilter selectedTypes={selectedTypes} onTypesChange={setSelectedTypes} typeCounts={typeCounts} />

            {/* Variable Classification - now uses filtered data */}
            {filteredClassifications.size > 0 && <VariableClassification classifications={filteredClassifications} />}

            {/* Statistics - now uses filtered data */}
            {filteredStatistics.size > 0 && <StatisticsPanel statistics={filteredStatistics} />}

            {/* Charts - now uses filtered data */}
            {filteredClassifications.size > 0 && (
              <ChartsPanel
                data={data}
                columns={Array.from(filteredClassifications.keys())}
                classifications={filteredClassifications}
                statistics={filteredStatistics}
              />
            )}
          </div>
        )}
      </main>
    </div>
  )
}
