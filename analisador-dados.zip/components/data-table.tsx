"use client"

import { Card } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { ScrollArea } from "@/components/ui/scroll-area"

interface DataTableProps {
  data: any[]
  columns: string[]
}

export function DataTable({ data, columns }: DataTableProps) {
  // Mostrar apenas as primeiras 100 linhas para performance
  const displayData = data.slice(0, 100)

  return (
    <Card className="overflow-hidden">
      <div className="border-b border-border bg-muted/30 px-6 py-4">
        <h2 className="text-lg font-semibold text-foreground">Visualização dos Dados</h2>
        <p className="text-sm text-muted-foreground">
          Mostrando {displayData.length} de {data.length} registros
        </p>
      </div>
      <ScrollArea className="h-[400px]">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-12 bg-muted/50">#</TableHead>
              {columns.map((col) => (
                <TableHead key={col} className="bg-muted/50 font-mono text-xs">
                  {col}
                </TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {displayData.map((row, idx) => (
              <TableRow key={idx}>
                <TableCell className="font-mono text-xs text-muted-foreground">{idx + 1}</TableCell>
                {columns.map((col) => (
                  <TableCell key={col} className="font-mono text-xs">
                    {row[col] !== null && row[col] !== undefined ? String(row[col]) : "-"}
                  </TableCell>
                ))}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </ScrollArea>
    </Card>
  )
}
