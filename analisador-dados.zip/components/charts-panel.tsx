"use client"

import { Card } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ScrollArea } from "@/components/ui/scroll-area"
import { BarChart } from "@/components/charts/bar-chart"
import { Histogram } from "@/components/charts/histogram"
import { BoxPlot } from "@/components/charts/box-plot"
import type { VariableInfo } from "@/lib/variable-classifier"
import type { VariableStatistics } from "@/lib/statistics"

interface ChartsPanelProps {
  data: any[]
  columns: string[]
  classifications: Map<string, VariableInfo>
  statistics: Map<string, VariableStatistics>
}

export function ChartsPanel({ data, columns, classifications, statistics }: ChartsPanelProps) {
  const varsArray = Array.from(classifications.values())

  return (
    <Card className="overflow-hidden">
      <div className="border-b border-border bg-muted/30 px-6 py-4">
        <h2 className="text-lg font-semibold text-foreground">Visualizações</h2>
        <p className="text-sm text-muted-foreground">Gráficos de barras, histogramas e boxplots</p>
      </div>

      <div className="p-6">
        <Tabs defaultValue={varsArray[0]?.name} className="w-full">
          <ScrollArea className="w-full">
            <TabsList className="inline-flex h-auto w-full justify-start">
              {varsArray.map((varInfo) => (
                <TabsTrigger key={varInfo.name} value={varInfo.name} className="font-mono text-xs">
                  {varInfo.name}
                </TabsTrigger>
              ))}
            </TabsList>
          </ScrollArea>

          {varsArray.map((varInfo) => {
            const values = data.map((row) => row[varInfo.name]).filter((v) => v !== null && v !== undefined && v !== "")
            const stats = statistics.get(varInfo.name)

            return (
              <TabsContent key={varInfo.name} value={varInfo.name} className="space-y-6">
                {/* Gráfico de barras para variáveis categóricas */}
                {(varInfo.type === "qualitativa-nominal" ||
                  varInfo.type === "qualitativa-ordinal" ||
                  varInfo.type === "binaria") && (
                  <div>
                    <h3 className="mb-4 text-sm font-semibold text-foreground">Gráfico de Barras</h3>
                    <BarChart data={values} variableName={varInfo.name} />
                  </div>
                )}

                {/* Histograma para variáveis numéricas */}
                {(varInfo.type === "quantitativa-discreta" || varInfo.type === "quantitativa-continua") &&
                  varInfo.isNumeric && (
                    <div>
                      <h3 className="mb-4 text-sm font-semibold text-foreground">Histograma</h3>
                      <Histogram data={values} variableName={varInfo.name} />
                    </div>
                  )}

                {/* Boxplot para variáveis numéricas */}
                {(varInfo.type === "quantitativa-discreta" || varInfo.type === "quantitativa-continua") &&
                  varInfo.isNumeric &&
                  stats?.separatrices && (
                    <div>
                      <h3 className="mb-4 text-sm font-semibold text-foreground">Boxplot (Diagrama de Caixa)</h3>
                      <BoxPlot
                        data={values}
                        variableName={varInfo.name}
                        q1={stats.separatrices.q1!}
                        q2={stats.separatrices.q2!}
                        q3={stats.separatrices.q3!}
                      />
                    </div>
                  )}
              </TabsContent>
            )
          })}
        </Tabs>
      </div>
    </Card>
  )
}
