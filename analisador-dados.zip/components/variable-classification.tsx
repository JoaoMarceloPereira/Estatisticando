"use client"

import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  type VariableInfo,
  getVariableTypeLabel,
  getVariableTypeDescription,
  getVariableTypeColor,
} from "@/lib/variable-classifier"
import { Info } from "lucide-react"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

interface VariableClassificationProps {
  classifications: Map<string, VariableInfo>
}

export function VariableClassification({ classifications }: VariableClassificationProps) {
  const classificationArray = Array.from(classifications.values())

  // Contar tipos
  const typeCounts = classificationArray.reduce(
    (acc, info) => {
      acc[info.type] = (acc[info.type] || 0) + 1
      return acc
    },
    {} as Record<string, number>,
  )

  return (
    <Card className="overflow-hidden">
      <div className="border-b border-border bg-muted/30 px-6 py-4">
        <h2 className="text-lg font-semibold text-foreground">Classificação de Variáveis</h2>
        <p className="text-sm text-muted-foreground">
          Identificação automática do tipo de cada variável para análise apropriada
        </p>
      </div>

      <div className="p-6">
        {/* Resumo dos tipos */}
        <div className="mb-6 grid grid-cols-2 gap-4 md:grid-cols-5">
          {Object.entries(typeCounts).map(([type, count]) => (
            <div key={type} className="rounded-lg border border-border bg-muted/30 p-3 text-center">
              <p className="text-2xl font-semibold text-foreground">{count}</p>
              <p className="text-xs text-muted-foreground">{getVariableTypeLabel(type as any)}</p>
            </div>
          ))}
        </div>

        {/* Lista de variáveis */}
        <div className="space-y-3">
          {classificationArray.map((info) => (
            <div
              key={info.name}
              className="flex items-start gap-4 rounded-lg border border-border bg-card p-4 transition-colors hover:bg-muted/30"
            >
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <h3 className="font-mono text-sm font-medium text-foreground">{info.name}</h3>
                  <Badge className={`border ${getVariableTypeColor(info.type)}`} variant="outline">
                    {getVariableTypeLabel(info.type)}
                  </Badge>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger>
                        <Info className="h-4 w-4 text-muted-foreground" />
                      </TooltipTrigger>
                      <TooltipContent className="max-w-xs">
                        <p className="text-xs">{getVariableTypeDescription(info.type)}</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>

                <div className="mt-2 flex flex-wrap gap-4 text-xs text-muted-foreground">
                  <span>Valores únicos: {info.uniqueValues}</span>
                  {info.nullCount > 0 && <span>Valores faltantes: {info.nullCount}</span>}
                  <span>Tipo: {info.isNumeric ? "Numérico" : "Categórico"}</span>
                  {info.isNumeric && info.hasDecimals && <span>Com decimais</span>}
                </div>

                <div className="mt-2">
                  <p className="text-xs text-muted-foreground">Exemplos:</p>
                  <div className="mt-1 flex flex-wrap gap-1">
                    {info.sampleValues.map((val, idx) => (
                      <code key={idx} className="rounded bg-muted px-2 py-0.5 font-mono text-xs text-foreground">
                        {String(val)}
                      </code>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </Card>
  )
}
