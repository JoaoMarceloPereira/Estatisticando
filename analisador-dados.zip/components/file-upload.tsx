"use client"

import { useCallback, useState } from "react"
import { useDropzone } from "react-dropzone"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Upload, FileSpreadsheet, AlertCircle } from "lucide-react"
import Papa from "papaparse"
import * as XLSX from "xlsx"

interface FileUploadProps {
  onDataLoaded: (data: any[], columns: string[], fileName: string) => void
}

export function FileUpload({ onDataLoaded }: FileUploadProps) {
  const [error, setError] = useState<string>("")
  const [loading, setLoading] = useState(false)

  const parseCSV = (file: File) => {
    Papa.parse(file, {
      header: true,
      dynamicTyping: true,
      skipEmptyLines: true,
      complete: (results) => {
        if (results.data.length > 0) {
          const columns = Object.keys(results.data[0])
          onDataLoaded(results.data, columns, file.name)
        } else {
          setError("Arquivo CSV vazio")
        }
        setLoading(false)
      },
      error: (err) => {
        setError(`Erro ao ler CSV: ${err.message}`)
        setLoading(false)
      },
    })
  }

  const parseTSV = (file: File) => {
    Papa.parse(file, {
      header: true,
      dynamicTyping: true,
      skipEmptyLines: true,
      delimiter: "\t",
      complete: (results) => {
        if (results.data.length > 0) {
          const columns = Object.keys(results.data[0])
          onDataLoaded(results.data, columns, file.name)
        } else {
          setError("Arquivo TSV vazio")
        }
        setLoading(false)
      },
      error: (err) => {
        setError(`Erro ao ler TSV: ${err.message}`)
        setLoading(false)
      },
    })
  }

  const parseExcel = (file: File) => {
    const reader = new FileReader()
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer)
        const workbook = XLSX.read(data, { type: "array" })
        const firstSheet = workbook.Sheets[workbook.SheetNames[0]]
        const jsonData = XLSX.utils.sheet_to_json(firstSheet)

        if (jsonData.length > 0) {
          const columns = Object.keys(jsonData[0])
          onDataLoaded(jsonData, columns, file.name)
        } else {
          setError("Arquivo Excel vazio")
        }
        setLoading(false)
      } catch (err) {
        setError(`Erro ao ler Excel: ${err}`)
        setLoading(false)
      }
    }
    reader.readAsArrayBuffer(file)
  }

  const parseJSON = (file: File) => {
    const reader = new FileReader()
    reader.onload = (e) => {
      try {
        const jsonData = JSON.parse(e.target?.result as string)
        const dataArray = Array.isArray(jsonData) ? jsonData : [jsonData]

        if (dataArray.length > 0) {
          const columns = Object.keys(dataArray[0])
          onDataLoaded(dataArray, columns, file.name)
        } else {
          setError("Arquivo JSON vazio")
        }
        setLoading(false)
      } catch (err) {
        setError(`Erro ao ler JSON: ${err}`)
        setLoading(false)
      }
    }
    reader.readAsText(file)
  }

  const onDrop = useCallback(
    (acceptedFiles: File[]) => {
      setError("")
      setLoading(true)

      const file = acceptedFiles[0]
      if (!file) {
        setLoading(false)
        return
      }

      const extension = file.name.split(".").pop()?.toLowerCase()

      switch (extension) {
        case "csv":
          parseCSV(file)
          break
        case "tsv":
          parseTSV(file)
          break
        case "xlsx":
        case "xls":
          parseExcel(file)
          break
        case "json":
          parseJSON(file)
          break
        default:
          setError("Formato não suportado. Use CSV, TSV, XLSX ou JSON")
          setLoading(false)
      }
    },
    [onDataLoaded],
  )

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      "text/csv": [".csv"],
      "text/tab-separated-values": [".tsv"],
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": [".xlsx"],
      "application/vnd.ms-excel": [".xls"],
      "application/json": [".json"],
    },
    multiple: false,
  })

  return (
    <Card className="w-full max-w-2xl p-8">
      <div className="space-y-6">
        <div className="text-center">
          <h2 className="text-2xl font-semibold text-foreground">Carregar Arquivo de Dados</h2>
          <p className="mt-2 text-sm text-muted-foreground">Suporta CSV, TSV, XLSX e JSON</p>
        </div>

        <div
          {...getRootProps()}
          className={`cursor-pointer rounded-lg border-2 border-dashed p-12 text-center transition-colors ${
            isDragActive ? "border-primary bg-primary/5" : "border-border hover:border-primary/50 hover:bg-muted/50"
          }`}
        >
          <input {...getInputProps()} />
          <div className="flex flex-col items-center gap-4">
            {loading ? (
              <>
                <div className="h-12 w-12 animate-spin rounded-full border-4 border-primary border-t-transparent" />
                <p className="text-sm text-muted-foreground">Processando arquivo...</p>
              </>
            ) : (
              <>
                <div className="rounded-full bg-primary/10 p-4">
                  {isDragActive ? (
                    <Upload className="h-8 w-8 text-primary" />
                  ) : (
                    <FileSpreadsheet className="h-8 w-8 text-primary" />
                  )}
                </div>
                <div>
                  <p className="text-base font-medium text-foreground">
                    {isDragActive ? "Solte o arquivo aqui" : "Arraste um arquivo ou clique para selecionar"}
                  </p>
                  <p className="mt-1 text-sm text-muted-foreground">CSV, TSV, XLSX ou JSON (máx. 50MB)</p>
                </div>
                <Button type="button" variant="outline">
                  Selecionar Arquivo
                </Button>
              </>
            )}
          </div>
        </div>

        {error && (
          <div className="flex items-start gap-3 rounded-lg border border-destructive/50 bg-destructive/10 p-4">
            <AlertCircle className="h-5 w-5 text-destructive" />
            <div className="flex-1">
              <p className="text-sm font-medium text-destructive">Erro</p>
              <p className="mt-1 text-sm text-destructive/90">{error}</p>
            </div>
          </div>
        )}

        <div className="rounded-lg border border-border bg-muted/30 p-4">
          <h3 className="text-sm font-medium text-foreground">Formatos suportados:</h3>
          <ul className="mt-2 space-y-1 text-sm text-muted-foreground">
            <li>• CSV - Valores separados por vírgula</li>
            <li>• TSV - Valores separados por tabulação</li>
            <li>• XLSX/XLS - Planilhas Excel</li>
            <li>• JSON - Arrays de objetos</li>
          </ul>
        </div>
      </div>
    </Card>
  )
}
