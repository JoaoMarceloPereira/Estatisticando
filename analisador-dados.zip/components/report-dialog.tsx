"use client"

import { useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Download, FileText, Code } from "lucide-react"
import {
  generateMarkdownReport,
  downloadMarkdownReport,
  generateHTMLReport,
  downloadHTMLReport,
} from "@/lib/report-generator"
import type { VariableInfo } from "@/lib/variable-classifier"
import type { VariableStatistics } from "@/lib/statistics"

interface ReportDialogProps {
  fileName: string
  data: any[]
  classifications: Map<string, VariableInfo>
  statistics: Map<string, VariableStatistics>
}

export function ReportDialog({ fileName, data, classifications, statistics }: ReportDialogProps) {
  const [open, setOpen] = useState(false)

  const handleDownloadMarkdown = () => {
    const report = generateMarkdownReport(fileName, data, classifications, statistics)
    downloadMarkdownReport(report, fileName)
  }

  const handleDownloadHTML = () => {
    const report = generateHTMLReport(fileName, data, classifications, statistics)
    downloadHTMLReport(report, fileName)
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline">
          <Download className="mr-2 h-4 w-4" />
          Exportar Relatório
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Exportar Relatório</DialogTitle>
          <DialogDescription>
            Escolha o formato para exportar o relatório completo com todas as análises estatísticas e explicações das
            fórmulas.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-3">
            <Button
              onClick={handleDownloadMarkdown}
              className="w-full justify-start bg-transparent"
              variant="outline"
              size="lg"
            >
              <FileText className="mr-3 h-5 w-5" />
              <div className="text-left">
                <p className="font-semibold">Markdown (.md)</p>
                <p className="text-xs text-muted-foreground">Formato de texto com formatação simples</p>
              </div>
            </Button>

            <Button
              onClick={handleDownloadHTML}
              className="w-full justify-start bg-transparent"
              variant="outline"
              size="lg"
            >
              <Code className="mr-3 h-5 w-5" />
              <div className="text-left">
                <p className="font-semibold">HTML (.html)</p>
                <p className="text-xs text-muted-foreground">Visualize no navegador com formatação completa</p>
              </div>
            </Button>
          </div>

          <div className="rounded-lg border border-border bg-muted/30 p-4">
            <h4 className="mb-2 text-sm font-semibold text-foreground">O relatório inclui:</h4>
            <ul className="space-y-1 text-xs text-muted-foreground">
              <li>• Classificação de todas as variáveis</li>
              <li>• Tabelas de frequências</li>
              <li>• Medidas de tendência central (média, mediana, moda)</li>
              <li>• Separatrizes (quartis, decis, percentis)</li>
              <li>• Medidas de dispersão (amplitude, variância, desvio padrão, IQR, CV)</li>
              <li>• Explicações detalhadas de todas as fórmulas</li>
            </ul>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
