"use client"

import { useMemo } from "react"
import { Bar, BarChart, CartesianGrid, XAxis, YAxis, ResponsiveContainer } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

interface HistogramProps {
  data: any[]
  variableName: string
}

export function Histogram({ data, variableName }: HistogramProps) {
  const chartData = useMemo(() => {
    // Converter para números
    const numbers = data.map((v) => Number(v)).filter((v) => !isNaN(v))

    if (numbers.length === 0) return []

    // Calcular número de bins usando regra de Sturges
    const n = numbers.length
    const numBins = Math.ceil(Math.log2(n) + 1)

    // Encontrar min e max
    const min = Math.min(...numbers)
    const max = Math.max(...numbers)
    const range = max - min
    const binWidth = range / numBins

    // Criar bins
    const bins = Array.from({ length: numBins }, (_, i) => ({
      start: min + i * binWidth,
      end: min + (i + 1) * binWidth,
      count: 0,
      label: "",
    }))

    // Contar valores em cada bin
    numbers.forEach((value) => {
      const binIndex = Math.min(Math.floor((value - min) / binWidth), numBins - 1)
      bins[binIndex].count++
    })

    // Formatar labels
    bins.forEach((bin) => {
      bin.label = `${bin.start.toFixed(1)} - ${bin.end.toFixed(1)}`
    })

    return bins
  }, [data])

  const chartConfig = {
    count: {
      label: "Frequência",
      color: "hsl(var(--chart-3))",
    },
  }

  return (
    <div className="h-[400px] w-full rounded-lg border border-border bg-card p-4">
      <ChartContainer config={chartConfig}>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 60 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis
              dataKey="label"
              angle={-45}
              textAnchor="end"
              height={80}
              tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }}
            />
            <YAxis tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }} />
            <ChartTooltip content={<ChartTooltipContent />} />
            <Bar dataKey="count" fill="hsl(var(--chart-3))" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </ChartContainer>
    </div>
  )
}
