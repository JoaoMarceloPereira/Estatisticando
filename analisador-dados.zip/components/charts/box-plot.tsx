"use client"

import { useMemo } from "react"

interface BoxPlotProps {
  data: any[]
  variableName: string
  q1: number
  q2: number
  q3: number
}

export function BoxPlot({ data, variableName, q1, q2, q3 }: BoxPlotProps) {
  const plotData = useMemo(() => {
    const numbers = data.map((v) => Number(v)).filter((v) => !isNaN(v))
    const sorted = [...numbers].sort((a, b) => a - b)

    const min = sorted[0]
    const max = sorted[sorted.length - 1]

    // Calcular limites para outliers (1.5 * IQR)
    const iqr = q3 - q1
    const lowerFence = q1 - 1.5 * iqr
    const upperFence = q3 + 1.5 * iqr

    // Encontrar whiskers (valores dentro dos limites)
    const lowerWhisker = sorted.find((v) => v >= lowerFence) || min
    const upperWhisker = sorted.reverse().find((v) => v <= upperFence) || max

    // Identificar outliers
    const outliers = numbers.filter((v) => v < lowerFence || v > upperFence)

    return {
      min,
      max,
      q1,
      q2,
      q3,
      lowerWhisker,
      upperWhisker,
      outliers,
      range: max - min,
    }
  }, [data, q1, q2, q3])

  // Escala para visualização
  const scale = 600 / plotData.range
  const offset = plotData.min

  const getY = (value: number) => {
    return 50 + (plotData.max - value) * scale
  }

  return (
    <div className="h-[400px] w-full rounded-lg border border-border bg-card p-8">
      <svg width="100%" height="100%" viewBox="0 0 800 400" className="overflow-visible">
        {/* Eixo Y */}
        <line x1="100" y1="50" x2="100" y2="350" stroke="hsl(var(--border))" strokeWidth="2" />

        {/* Labels do eixo Y */}
        <text x="80" y={getY(plotData.max)} textAnchor="end" fill="hsl(var(--muted-foreground))" fontSize="12">
          {plotData.max.toFixed(2)}
        </text>
        <text x="80" y={getY(plotData.q3)} textAnchor="end" fill="hsl(var(--muted-foreground))" fontSize="12">
          {plotData.q3.toFixed(2)}
        </text>
        <text x="80" y={getY(plotData.q2)} textAnchor="end" fill="hsl(var(--muted-foreground))" fontSize="12">
          {plotData.q2.toFixed(2)}
        </text>
        <text x="80" y={getY(plotData.q1)} textAnchor="end" fill="hsl(var(--muted-foreground))" fontSize="12">
          {plotData.q1.toFixed(2)}
        </text>
        <text x="80" y={getY(plotData.min)} textAnchor="end" fill="hsl(var(--muted-foreground))" fontSize="12">
          {plotData.min.toFixed(2)}
        </text>

        {/* Whisker superior */}
        <line
          x1="300"
          y1={getY(plotData.upperWhisker)}
          x2="300"
          y2={getY(plotData.q3)}
          stroke="hsl(var(--foreground))"
          strokeWidth="2"
        />
        <line
          x1="250"
          y1={getY(plotData.upperWhisker)}
          x2="350"
          y2={getY(plotData.upperWhisker)}
          stroke="hsl(var(--foreground))"
          strokeWidth="2"
        />

        {/* Caixa (Q1 a Q3) */}
        <rect
          x="200"
          y={getY(plotData.q3)}
          width="200"
          height={getY(plotData.q1) - getY(plotData.q3)}
          fill="hsl(var(--chart-4) / 0.3)"
          stroke="hsl(var(--chart-4))"
          strokeWidth="2"
        />

        {/* Mediana (Q2) */}
        <line
          x1="200"
          y1={getY(plotData.q2)}
          x2="400"
          y2={getY(plotData.q2)}
          stroke="hsl(var(--foreground))"
          strokeWidth="3"
        />

        {/* Whisker inferior */}
        <line
          x1="300"
          y1={getY(plotData.q1)}
          x2="300"
          y2={getY(plotData.lowerWhisker)}
          stroke="hsl(var(--foreground))"
          strokeWidth="2"
        />
        <line
          x1="250"
          y1={getY(plotData.lowerWhisker)}
          x2="350"
          y2={getY(plotData.lowerWhisker)}
          stroke="hsl(var(--foreground))"
          strokeWidth="2"
        />

        {/* Outliers */}
        {plotData.outliers.map((outlier, idx) => (
          <circle
            key={idx}
            cx="300"
            cy={getY(outlier)}
            r="4"
            fill="hsl(var(--destructive))"
            stroke="hsl(var(--destructive))"
            strokeWidth="1"
          />
        ))}

        {/* Legenda */}
        <text x="450" y="100" fill="hsl(var(--foreground))" fontSize="14" fontWeight="600">
          Legenda:
        </text>
        <line x1="450" y1="130" x2="500" y2="130" stroke="hsl(var(--foreground))" strokeWidth="3" />
        <text x="510" y="135" fill="hsl(var(--muted-foreground))" fontSize="12">
          Mediana (Q2)
        </text>

        <rect x="450" y="150" width="50" height="30" fill="hsl(var(--chart-4) / 0.3)" stroke="hsl(var(--chart-4))" />
        <text x="510" y="170" fill="hsl(var(--muted-foreground))" fontSize="12">
          Caixa (Q1-Q3)
        </text>

        <line x1="450" y1="200" x2="500" y2="200" stroke="hsl(var(--foreground))" strokeWidth="2" />
        <text x="510" y="205" fill="hsl(var(--muted-foreground))" fontSize="12">
          Whiskers
        </text>

        <circle cx="475" cy="230" r="4" fill="hsl(var(--destructive))" />
        <text x="510" y="235" fill="hsl(var(--muted-foreground))" fontSize="12">
          Outliers
        </text>
      </svg>

      {/* Informações adicionais */}
      <div className="mt-4 grid grid-cols-3 gap-4 text-xs">
        <div>
          <p className="text-muted-foreground">Mínimo</p>
          <p className="font-mono font-semibold text-foreground">{plotData.min.toFixed(2)}</p>
        </div>
        <div>
          <p className="text-muted-foreground">Máximo</p>
          <p className="font-mono font-semibold text-foreground">{plotData.max.toFixed(2)}</p>
        </div>
        <div>
          <p className="text-muted-foreground">Outliers</p>
          <p className="font-mono font-semibold text-foreground">{plotData.outliers.length}</p>
        </div>
      </div>
    </div>
  )
}
