"use client"

import { useMemo } from "react"
import { Bar, BarChart as RechartsBarChart, CartesianGrid, XAxis, YAxis, ResponsiveContainer } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

interface BarChartProps {
  data: any[]
  variableName: string
}

export function BarChart({ data, variableName }: BarChartProps) {
  const chartData = useMemo(() => {
    // Contar frequências
    const counts = new Map<any, number>()
    data.forEach((value) => {
      counts.set(value, (counts.get(value) || 0) + 1)
    })

    // Converter para array e ordenar por frequência
    return Array.from(counts.entries())
      .map(([value, count]) => ({
        category: String(value),
        frequency: count,
      }))
      .sort((a, b) => b.frequency - a.frequency)
      .slice(0, 20) // Limitar a 20 categorias
  }, [data])

  const chartConfig = {
    frequency: {
      label: "Frequência",
      color: "hsl(var(--chart-1))",
    },
  }

  return (
    <div className="h-[400px] w-full rounded-lg border border-border bg-card p-4">
      <ChartContainer config={chartConfig}>
        <ResponsiveContainer width="100%" height="100%">
          <RechartsBarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 60 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis
              dataKey="category"
              angle={-45}
              textAnchor="end"
              height={80}
              tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }}
            />
            <YAxis tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }} />
            <ChartTooltip content={<ChartTooltipContent />} />
            <Bar dataKey="frequency" fill="hsl(var(--chart-1))" radius={[4, 4, 0, 0]} />
          </RechartsBarChart>
        </ResponsiveContainer>
      </ChartContainer>
    </div>
  )
}
