"use client"

import { Card } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import type { VariableStatistics } from "@/lib/statistics"
import { Info } from "lucide-react"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

interface StatisticsPanelProps {
  statistics: Map<string, VariableStatistics>
}

export function StatisticsPanel({ statistics }: StatisticsPanelProps) {
  const statsArray = Array.from(statistics.values())

  return (
    <Card className="overflow-hidden">
      <div className="border-b border-border bg-muted/30 px-6 py-4">
        <h2 className="text-lg font-semibold text-foreground">Análise Estatística</h2>
        <p className="text-sm text-muted-foreground">Frequências, tendências centrais, separatrizes e dispersão</p>
      </div>

      <div className="p-6">
        <Tabs defaultValue={statsArray[0]?.variable} className="w-full">
          <ScrollArea className="w-full">
            <TabsList className="inline-flex h-auto w-full justify-start">
              {statsArray.map((stat) => (
                <TabsTrigger key={stat.variable} value={stat.variable} className="font-mono text-xs">
                  {stat.variable}
                </TabsTrigger>
              ))}
            </TabsList>
          </ScrollArea>

          {statsArray.map((stat) => (
            <TabsContent key={stat.variable} value={stat.variable} className="space-y-6">
              {/* Informações gerais */}
              <div className="grid grid-cols-3 gap-4">
                <div className="rounded-lg border border-border bg-muted/30 p-4">
                  <p className="text-sm text-muted-foreground">Tipo</p>
                  <p className="mt-1 text-base font-medium text-foreground">{stat.type}</p>
                </div>
                <div className="rounded-lg border border-border bg-muted/30 p-4">
                  <p className="text-sm text-muted-foreground">Valores válidos</p>
                  <p className="mt-1 text-base font-medium text-foreground">{stat.validCount}</p>
                </div>
                <div className="rounded-lg border border-border bg-muted/30 p-4">
                  <p className="text-sm text-muted-foreground">Valores faltantes</p>
                  <p className="mt-1 text-base font-medium text-foreground">{stat.nullCount}</p>
                </div>
              </div>

              {/* Frequências */}
              {stat.frequencies && stat.frequencies.length > 0 && (
                <div>
                  <div className="mb-3 flex items-center gap-2">
                    <h3 className="text-sm font-semibold text-foreground">Distribuição de Frequências</h3>
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger>
                          <Info className="h-4 w-4 text-muted-foreground" />
                        </TooltipTrigger>
                        <TooltipContent className="max-w-xs">
                          <p className="text-xs">
                            Frequência absoluta: contagem de ocorrências
                            <br />
                            Frequência relativa: proporção do total
                            <br />
                            Frequência acumulada: soma progressiva
                          </p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </div>
                  <ScrollArea className="h-[300px] rounded-lg border border-border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Valor</TableHead>
                          <TableHead className="text-right">Freq. Absoluta</TableHead>
                          <TableHead className="text-right">Freq. Relativa</TableHead>
                          <TableHead className="text-right">Freq. Acumulada</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {stat.frequencies.map((freq, idx) => (
                          <TableRow key={idx}>
                            <TableCell className="font-mono text-xs">{String(freq.value)}</TableCell>
                            <TableCell className="text-right font-mono text-xs">{freq.absolute}</TableCell>
                            <TableCell className="text-right font-mono text-xs">{freq.relativePercent}</TableCell>
                            <TableCell className="text-right font-mono text-xs">{freq.accumulatedPercent}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </ScrollArea>
                </div>
              )}

              {/* Tendências Centrais */}
              <div>
                <div className="mb-3 flex items-center gap-2">
                  <h3 className="text-sm font-semibold text-foreground">Medidas de Tendência Central</h3>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger>
                        <Info className="h-4 w-4 text-muted-foreground" />
                      </TooltipTrigger>
                      <TooltipContent className="max-w-xs">
                        <p className="text-xs">
                          Média: Σx/n (soma dividida pela quantidade)
                          <br />
                          Mediana: valor central quando ordenado
                          <br />
                          Moda: valor(es) mais frequente(s)
                        </p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  {stat.centralTendency.mean !== undefined && (
                    <div className="rounded-lg border border-border bg-card p-4">
                      <p className="text-sm text-muted-foreground">Média</p>
                      <p className="mt-1 font-mono text-xl font-semibold text-foreground">
                        {stat.centralTendency.mean.toFixed(2)}
                      </p>
                    </div>
                  )}
                  {stat.centralTendency.median !== undefined && (
                    <div className="rounded-lg border border-border bg-card p-4">
                      <p className="text-sm text-muted-foreground">Mediana</p>
                      <p className="mt-1 font-mono text-xl font-semibold text-foreground">
                        {stat.centralTendency.median.toFixed(2)}
                      </p>
                    </div>
                  )}
                  <div className="rounded-lg border border-border bg-card p-4">
                    <p className="text-sm text-muted-foreground">Moda</p>
                    <div className="mt-1 flex flex-wrap gap-1">
                      {stat.centralTendency.mode.slice(0, 3).map((mode, idx) => (
                        <Badge key={idx} variant="secondary" className="font-mono text-xs">
                          {String(mode)}
                        </Badge>
                      ))}
                      {stat.centralTendency.mode.length > 3 && (
                        <Badge variant="secondary" className="text-xs">
                          +{stat.centralTendency.mode.length - 3}
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Separatrizes */}
              {stat.separatrices && (
                <div>
                  <div className="mb-3 flex items-center gap-2">
                    <h3 className="text-sm font-semibold text-foreground">Separatrizes</h3>
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger>
                          <Info className="h-4 w-4 text-muted-foreground" />
                        </TooltipTrigger>
                        <TooltipContent className="max-w-xs">
                          <p className="text-xs">
                            Quartis: dividem os dados em 4 partes (25%, 50%, 75%)
                            <br />
                            Decis: dividem em 10 partes
                            <br />
                            Percentis: dividem em 100 partes
                          </p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </div>
                  <div className="space-y-4">
                    <div>
                      <p className="mb-2 text-xs font-medium text-muted-foreground">Quartis</p>
                      <div className="grid grid-cols-3 gap-3">
                        <div className="rounded-lg border border-border bg-card p-3">
                          <p className="text-xs text-muted-foreground">Q1 (25%)</p>
                          <p className="font-mono text-sm font-semibold text-foreground">
                            {stat.separatrices.q1?.toFixed(2)}
                          </p>
                        </div>
                        <div className="rounded-lg border border-border bg-card p-3">
                          <p className="text-xs text-muted-foreground">Q2 (50%)</p>
                          <p className="font-mono text-sm font-semibold text-foreground">
                            {stat.separatrices.q2?.toFixed(2)}
                          </p>
                        </div>
                        <div className="rounded-lg border border-border bg-card p-3">
                          <p className="text-xs text-muted-foreground">Q3 (75%)</p>
                          <p className="font-mono text-sm font-semibold text-foreground">
                            {stat.separatrices.q3?.toFixed(2)}
                          </p>
                        </div>
                      </div>
                    </div>
                    <div>
                      <p className="mb-2 text-xs font-medium text-muted-foreground">Decis</p>
                      <div className="grid grid-cols-3 gap-3">
                        <div className="rounded-lg border border-border bg-card p-3">
                          <p className="text-xs text-muted-foreground">D1 (10%)</p>
                          <p className="font-mono text-sm font-semibold text-foreground">
                            {stat.separatrices.d1?.toFixed(2)}
                          </p>
                        </div>
                        <div className="rounded-lg border border-border bg-card p-3">
                          <p className="text-xs text-muted-foreground">D5 (50%)</p>
                          <p className="font-mono text-sm font-semibold text-foreground">
                            {stat.separatrices.d5?.toFixed(2)}
                          </p>
                        </div>
                        <div className="rounded-lg border border-border bg-card p-3">
                          <p className="text-xs text-muted-foreground">D9 (90%)</p>
                          <p className="font-mono text-sm font-semibold text-foreground">
                            {stat.separatrices.d9?.toFixed(2)}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Dispersão */}
              {stat.dispersion && (
                <div>
                  <div className="mb-3 flex items-center gap-2">
                    <h3 className="text-sm font-semibold text-foreground">Medidas de Dispersão</h3>
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger>
                          <Info className="h-4 w-4 text-muted-foreground" />
                        </TooltipTrigger>
                        <TooltipContent className="max-w-xs">
                          <p className="text-xs">
                            Amplitude: máximo - mínimo
                            <br />
                            Variância: Σ(x-μ)²/n
                            <br />
                            Desvio padrão: √variância
                            <br />
                            IQR: Q3 - Q1
                            <br />
                            CV: (σ/μ) × 100%
                          </p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </div>
                  <div className="grid grid-cols-2 gap-4 md:grid-cols-5">
                    <div className="rounded-lg border border-border bg-card p-4">
                      <p className="text-sm text-muted-foreground">Amplitude</p>
                      <p className="mt-1 font-mono text-lg font-semibold text-foreground">
                        {stat.dispersion.range?.toFixed(2)}
                      </p>
                    </div>
                    <div className="rounded-lg border border-border bg-card p-4">
                      <p className="text-sm text-muted-foreground">Variância</p>
                      <p className="mt-1 font-mono text-lg font-semibold text-foreground">
                        {stat.dispersion.variance?.toFixed(2)}
                      </p>
                    </div>
                    <div className="rounded-lg border border-border bg-card p-4">
                      <p className="text-sm text-muted-foreground">Desvio Padrão</p>
                      <p className="mt-1 font-mono text-lg font-semibold text-foreground">
                        {stat.dispersion.stdDev?.toFixed(2)}
                      </p>
                    </div>
                    <div className="rounded-lg border border-border bg-card p-4">
                      <p className="text-sm text-muted-foreground">IQR (Q3-Q1)</p>
                      <p className="mt-1 font-mono text-lg font-semibold text-foreground">
                        {stat.dispersion.iqr?.toFixed(2)}
                      </p>
                    </div>
                    <div className="rounded-lg border border-border bg-card p-4">
                      <p className="text-sm text-muted-foreground">CV</p>
                      <p className="mt-1 font-mono text-lg font-semibold text-foreground">
                        {stat.dispersion.cv?.toFixed(2)}%
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </Card>
  )
}
