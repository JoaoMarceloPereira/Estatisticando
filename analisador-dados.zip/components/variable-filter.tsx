"use client"

import { Card } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { type VariableType, getVariableTypeLabel } from "@/lib/variable-classifier"
import { Filter } from "lucide-react"

interface VariableFilterProps {
  selectedTypes: Set<VariableType>
  onTypesChange: (types: Set<VariableType>) => void
  typeCounts: Record<VariableType, number>
}

const allTypes: VariableType[] = [
  "qualitativa-nominal",
  "qualitativa-ordinal",
  "quantitativa-discreta",
  "quantitativa-continua",
  "binaria",
]

export function VariableFilter({ selectedTypes, onTypesChange, typeCounts }: VariableFilterProps) {
  const handleToggle = (type: VariableType) => {
    const newTypes = new Set(selectedTypes)
    if (newTypes.has(type)) {
      newTypes.delete(type)
    } else {
      newTypes.add(type)
    }
    onTypesChange(newTypes)
  }

  const handleSelectAll = () => {
    onTypesChange(new Set(allTypes))
  }

  const handleDeselectAll = () => {
    onTypesChange(new Set())
  }

  return (
    <Card className="overflow-hidden">
      <div className="border-b border-border bg-muted/30 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Filter className="h-5 w-5 text-muted-foreground" />
            <h2 className="text-lg font-semibold text-foreground">Filtrar Variáveis</h2>
          </div>
          <div className="flex gap-2">
            <button onClick={handleSelectAll} className="text-xs text-primary hover:underline">
              Selecionar todos
            </button>
            <span className="text-xs text-muted-foreground">|</span>
            <button onClick={handleDeselectAll} className="text-xs text-primary hover:underline">
              Limpar
            </button>
          </div>
        </div>
        <p className="mt-1 text-sm text-muted-foreground">Escolha quais tipos de variáveis deseja analisar</p>
      </div>

      <div className="p-6">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {allTypes.map((type) => {
            const count = typeCounts[type] || 0
            const isDisabled = count === 0

            return (
              <div
                key={type}
                className={`flex items-center space-x-3 rounded-lg border border-border p-4 transition-colors ${
                  isDisabled
                    ? "opacity-50"
                    : selectedTypes.has(type)
                      ? "bg-primary/5 border-primary/20"
                      : "hover:bg-muted/30"
                }`}
              >
                <Checkbox
                  id={type}
                  checked={selectedTypes.has(type)}
                  onCheckedChange={() => handleToggle(type)}
                  disabled={isDisabled}
                />
                <Label
                  htmlFor={type}
                  className={`flex-1 cursor-pointer text-sm ${isDisabled ? "cursor-not-allowed" : ""}`}
                >
                  <div className="font-medium text-foreground">{getVariableTypeLabel(type)}</div>
                  <div className="text-xs text-muted-foreground">
                    {count} {count === 1 ? "variável" : "variáveis"}
                  </div>
                </Label>
              </div>
            )
          })}
        </div>

        {selectedTypes.size === 0 && (
          <div className="mt-4 rounded-lg border border-amber-500/20 bg-amber-500/10 p-4 text-center">
            <p className="text-sm text-amber-600 dark:text-amber-400">
              Nenhum tipo de variável selecionado. Selecione ao menos um tipo para visualizar as análises.
            </p>
          </div>
        )}
      </div>
    </Card>
  )
}
