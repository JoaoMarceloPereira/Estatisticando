import type { VariableInfo } from "./variable-classifier"

export interface FrequencyData {
  value: any
  absolute: number
  relative: number
  relativePercent: string
  accumulated: number
  accumulatedPercent: string
}

export interface CentralTendency {
  mean?: number
  median?: number
  mode: any[]
  modeFrequency?: number
}

export interface Separatrices {
  q1?: number // 1º quartil (25%)
  q2?: number // 2º quartil (50% - mediana)
  q3?: number // 3º quartil (75%)
  d1?: number // 1º decil (10%)
  d5?: number // 5º decil (50%)
  d9?: number // 9º decil (90%)
  p10?: number // 10º percentil
  p25?: number // 25º percentil
  p50?: number // 50º percentil
  p75?: number // 75º percentil
  p90?: number // 90º percentil
}

export interface Dispersion {
  range?: number // amplitude
  variance?: number // variância
  stdDev?: number // desvio padrão
  iqr?: number // Q3 - Q1 (amplitude interquartil)
  cv?: number // coeficiente de variação (%)
}

export interface VariableStatistics {
  variable: string
  type: string
  frequencies?: FrequencyData[]
  centralTendency: CentralTendency
  separatrices?: Separatrices
  dispersion?: Dispersion
  validCount: number
  nullCount: number
}

// Calcular frequências
export function calculateFrequencies(values: any[]): FrequencyData[] {
  const validValues = values.filter((v) => v !== null && v !== undefined && v !== "")
  const total = validValues.length

  // Contar frequências
  const counts = new Map<any, number>()
  validValues.forEach((v) => {
    counts.set(v, (counts.get(v) || 0) + 1)
  })

  // Ordenar por valor
  const sorted = Array.from(counts.entries()).sort((a, b) => {
    if (typeof a[0] === "number" && typeof b[0] === "number") {
      return a[0] - b[0]
    }
    return String(a[0]).localeCompare(String(b[0]))
  })

  // Calcular frequências relativas e acumuladas
  let accumulated = 0
  return sorted.map(([value, absolute]) => {
    const relative = absolute / total
    accumulated += absolute
    return {
      value,
      absolute,
      relative,
      relativePercent: (relative * 100).toFixed(2) + "%",
      accumulated,
      accumulatedPercent: ((accumulated / total) * 100).toFixed(2) + "%",
    }
  })
}

// Calcular média
export function calculateMean(values: number[]): number {
  if (values.length === 0) return 0
  return values.reduce((sum, v) => sum + v, 0) / values.length
}

// Calcular mediana
export function calculateMedian(values: number[]): number {
  if (values.length === 0) return 0
  const sorted = [...values].sort((a, b) => a - b)
  const mid = Math.floor(sorted.length / 2)
  return sorted.length % 2 === 0 ? (sorted[mid - 1] + sorted[mid]) / 2 : sorted[mid]
}

// Calcular moda
export function calculateMode(values: any[]): { mode: any[]; frequency: number } {
  const counts = new Map<any, number>()
  values.forEach((v) => {
    counts.set(v, (counts.get(v) || 0) + 1)
  })

  const maxFreq = Math.max(...counts.values())
  const modes = Array.from(counts.entries())
    .filter(([_, freq]) => freq === maxFreq)
    .map(([value, _]) => value)

  return { mode: modes, frequency: maxFreq }
}

// Calcular percentil
export function calculatePercentile(values: number[], percentile: number): number {
  if (values.length === 0) return 0
  const sorted = [...values].sort((a, b) => a - b)
  const index = (percentile / 100) * (sorted.length - 1)
  const lower = Math.floor(index)
  const upper = Math.ceil(index)
  const weight = index - lower

  if (lower === upper) return sorted[lower]
  return sorted[lower] * (1 - weight) + sorted[upper] * weight
}

// Calcular variância
export function calculateVariance(values: number[], mean: number): number {
  if (values.length === 0) return 0
  const squaredDiffs = values.map((v) => Math.pow(v - mean, 2))
  return squaredDiffs.reduce((sum, v) => sum + v, 0) / values.length
}

// Calcular desvio padrão
export function calculateStdDev(variance: number): number {
  return Math.sqrt(variance)
}

// Calcular coeficiente de variação
export function calculateCV(stdDev: number, mean: number): number {
  if (mean === 0) return 0
  return (stdDev / Math.abs(mean)) * 100
}

// Calcular estatísticas completas para uma variável
export function calculateVariableStatistics(variableInfo: VariableInfo, data: any[]): VariableStatistics {
  const values = data.map((row) => row[variableInfo.name])
  const validValues = values.filter((v) => v !== null && v !== undefined && v !== "")
  const nullCount = values.length - validValues.length

  const stats: VariableStatistics = {
    variable: variableInfo.name,
    type: variableInfo.type,
    validCount: validValues.length,
    nullCount,
    centralTendency: { mode: [] },
  }

  // Calcular frequências (para todas as variáveis, mas limitar para numéricas contínuas)
  if (variableInfo.type !== "quantitativa-continua" || variableInfo.uniqueValues <= 20) {
    stats.frequencies = calculateFrequencies(validValues)
  }

  // Calcular moda (para todas as variáveis)
  const modeResult = calculateMode(validValues)
  stats.centralTendency.mode = modeResult.mode
  stats.centralTendency.modeFrequency = modeResult.frequency

  // Estatísticas numéricas (apenas para variáveis quantitativas)
  if (variableInfo.isNumeric) {
    const numericValues = validValues.map((v) => Number(v)).filter((v) => !isNaN(v))

    if (numericValues.length > 0) {
      // Tendências centrais
      const mean = calculateMean(numericValues)
      const median = calculateMedian(numericValues)
      stats.centralTendency.mean = mean
      stats.centralTendency.median = median

      // Separatrizes
      stats.separatrices = {
        q1: calculatePercentile(numericValues, 25),
        q2: calculatePercentile(numericValues, 50),
        q3: calculatePercentile(numericValues, 75),
        d1: calculatePercentile(numericValues, 10),
        d5: calculatePercentile(numericValues, 50),
        d9: calculatePercentile(numericValues, 90),
        p10: calculatePercentile(numericValues, 10),
        p25: calculatePercentile(numericValues, 25),
        p50: calculatePercentile(numericValues, 50),
        p75: calculatePercentile(numericValues, 75),
        p90: calculatePercentile(numericValues, 90),
      }

      // Dispersão
      const sortedValues = [...numericValues].sort((a, b) => a - b)
      const range = sortedValues[sortedValues.length - 1] - sortedValues[0]
      const variance = calculateVariance(numericValues, mean)
      const stdDev = calculateStdDev(variance)
      const iqr = stats.separatrices.q3! - stats.separatrices.q1!
      const cv = calculateCV(stdDev, mean)

      stats.dispersion = {
        range,
        variance,
        stdDev,
        iqr,
        cv,
      }
    }
  }

  return stats
}

// Calcular estatísticas para todo o dataset
export function calculateDatasetStatistics(
  data: any[],
  classifications: Map<string, VariableInfo>,
): Map<string, VariableStatistics> {
  const statistics = new Map<string, VariableStatistics>()

  classifications.forEach((varInfo, varName) => {
    const stats = calculateVariableStatistics(varInfo, data)
    statistics.set(varName, stats)
  })

  return statistics
}
