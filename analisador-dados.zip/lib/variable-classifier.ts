export type VariableType =
  | "qualitativa-nominal"
  | "qualitativa-ordinal"
  | "quantitativa-discreta"
  | "quantitativa-continua"
  | "binaria"

export interface VariableInfo {
  name: string
  type: VariableType
  uniqueValues: number
  nullCount: number
  sampleValues: any[]
  isNumeric: boolean
  hasDecimals: boolean
}

export function classifyVariable(columnName: string, values: any[]): VariableInfo {
  // Remover valores nulos/undefined
  const validValues = values.filter((v) => v !== null && v !== undefined && v !== "")
  const nullCount = values.length - validValues.length

  // Obter valores únicos
  const uniqueValues = new Set(validValues)
  const uniqueCount = uniqueValues.size
  const sampleValues = Array.from(uniqueValues).slice(0, 5)

  // Verificar se é numérico
  const numericValues = validValues.filter((v) => typeof v === "number" || !isNaN(Number(v)))
  const isNumeric = numericValues.length / validValues.length > 0.8 // 80% dos valores são numéricos

  if (!isNumeric) {
    // Variável categórica (não numérica)
    if (uniqueCount === 2) {
      return {
        name: columnName,
        type: "binaria",
        uniqueValues: uniqueCount,
        nullCount,
        sampleValues,
        isNumeric: false,
        hasDecimals: false,
      }
    }

    // Tentar detectar se é ordinal (palavras como "baixo", "médio", "alto", etc.)
    const ordinalPatterns = [
      /^(baixo|medio|alto)$/i,
      /^(pequeno|medio|grande)$/i,
      /^(ruim|regular|bom|otimo)$/i,
      /^(primeiro|segundo|terceiro)$/i,
      /^(1º|2º|3º|4º|5º)$/,
    ]

    const hasOrdinalPattern = sampleValues.some((v) => ordinalPatterns.some((pattern) => pattern.test(String(v))))

    return {
      name: columnName,
      type: hasOrdinalPattern ? "qualitativa-ordinal" : "qualitativa-nominal",
      uniqueValues: uniqueCount,
      nullCount,
      sampleValues,
      isNumeric: false,
      hasDecimals: false,
    }
  }

  // Variável numérica
  const numbers = numericValues.map((v) => Number(v))

  // Verificar se tem decimais
  const hasDecimals = numbers.some((n) => n % 1 !== 0)

  // Binária numérica (0/1, true/false)
  if (uniqueCount === 2) {
    const vals = Array.from(uniqueValues).map((v) => Number(v))
    if (vals.every((v) => v === 0 || v === 1)) {
      return {
        name: columnName,
        type: "binaria",
        uniqueValues: uniqueCount,
        nullCount,
        sampleValues,
        isNumeric: true,
        hasDecimals: false,
      }
    }
  }

  // Quantitativa discreta: números inteiros com poucos valores únicos relativos ao total
  if (!hasDecimals && uniqueCount < validValues.length * 0.5) {
    return {
      name: columnName,
      type: "quantitativa-discreta",
      uniqueValues: uniqueCount,
      nullCount,
      sampleValues,
      isNumeric: true,
      hasDecimals: false,
    }
  }

  // Quantitativa contínua: números com decimais ou muitos valores únicos
  return {
    name: columnName,
    type: "quantitativa-continua",
    uniqueValues: uniqueCount,
    nullCount,
    sampleValues,
    isNumeric: true,
    hasDecimals,
  }
}

export function classifyDataset(data: any[], columns: string[]): Map<string, VariableInfo> {
  const classifications = new Map<string, VariableInfo>()

  for (const column of columns) {
    const values = data.map((row) => row[column])
    const info = classifyVariable(column, values)
    classifications.set(column, info)
  }

  return classifications
}

export function getVariableTypeLabel(type: VariableType): string {
  const labels: Record<VariableType, string> = {
    "qualitativa-nominal": "Qualitativa Nominal",
    "qualitativa-ordinal": "Qualitativa Ordinal",
    "quantitativa-discreta": "Quantitativa Discreta",
    "quantitativa-continua": "Quantitativa Contínua",
    binaria: "Binária",
  }
  return labels[type]
}

export function getVariableTypeDescription(type: VariableType): string {
  const descriptions: Record<VariableType, string> = {
    "qualitativa-nominal": "Categorias sem ordem natural (ex: cores, nomes, categorias)",
    "qualitativa-ordinal": "Categorias com ordem natural (ex: baixo/médio/alto, 1º/2º/3º)",
    "quantitativa-discreta": "Números inteiros contáveis (ex: quantidade, idade em anos)",
    "quantitativa-continua": "Números com decimais, medições contínuas (ex: altura, peso, temperatura)",
    binaria: "Apenas dois valores possíveis (ex: sim/não, 0/1, verdadeiro/falso)",
  }
  return descriptions[type]
}

export function getVariableTypeColor(type: VariableType): string {
  const colors: Record<VariableType, string> = {
    "qualitativa-nominal": "bg-chart-1/10 text-chart-1 border-chart-1/20",
    "qualitativa-ordinal": "bg-chart-2/10 text-chart-2 border-chart-2/20",
    "quantitativa-discreta": "bg-chart-3/10 text-chart-3 border-chart-3/20",
    "quantitativa-continua": "bg-chart-4/10 text-chart-4 border-chart-4/20",
    binaria: "bg-chart-5/10 text-chart-5 border-chart-5/20",
  }
  return colors[type]
}
