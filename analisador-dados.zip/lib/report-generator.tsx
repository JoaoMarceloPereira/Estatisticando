import type { VariableInfo } from "./variable-classifier"
import type { VariableStatistics } from "./statistics"
import { getVariableTypeLabel, getVariableTypeDescription } from "./variable-classifier"

export function generateMarkdownReport(
  fileName: string,
  data: any[],
  classifications: Map<string, VariableInfo>,
  statistics: Map<string, VariableStatistics>,
): string {
  const date = new Date().toLocaleDateString("pt-BR")
  const time = new Date().toLocaleTimeString("pt-BR")

  let report = `# Relatório de Análise Estatística

**Arquivo:** ${fileName}  
**Data:** ${date} às ${time}  
**Total de registros:** ${data.length}

---

## 1. Resumo do Dataset

Este relatório apresenta uma análise estatística completa do conjunto de dados fornecido, incluindo classificação de variáveis, medidas de tendência central, separatrizes e dispersão.

### Variáveis Analisadas

Total de variáveis: ${classifications.size}

`

  // Contar tipos de variáveis
  const typeCounts = new Map<string, number>()
  classifications.forEach((info) => {
    typeCounts.set(info.type, (typeCounts.get(info.type) || 0) + 1)
  })

  typeCounts.forEach((count, type) => {
    report += `- **${getVariableTypeLabel(type as any)}:** ${count} variável(is)\n`
  })

  report += `\n---\n\n## 2. Classificação das Variáveis\n\n`

  classifications.forEach((varInfo) => {
    report += `### ${varInfo.name}\n\n`
    report += `- **Tipo:** ${getVariableTypeLabel(varInfo.type)}\n`
    report += `- **Descrição:** ${getVariableTypeDescription(varInfo.type)}\n`
    report += `- **Valores únicos:** ${varInfo.uniqueValues}\n`
    report += `- **Valores faltantes:** ${varInfo.nullCount}\n`
    report += `- **Exemplos:** ${varInfo.sampleValues.map((v) => `\`${v}\``).join(", ")}\n\n`
  })

  report += `---\n\n## 3. Análise Estatística Detalhada\n\n`

  statistics.forEach((stat) => {
    report += `### ${stat.variable}\n\n`

    // Frequências
    if (stat.frequencies && stat.frequencies.length > 0 && stat.frequencies.length <= 20) {
      report += `#### Distribuição de Frequências\n\n`
      report += `**Fórmulas:**\n`
      report += `- Frequência Absoluta (fa): contagem de ocorrências\n`
      report += `- Frequência Relativa (fr): fa / n (onde n = total de observações)\n`
      report += `- Frequência Acumulada (Fa): soma progressiva das frequências\n\n`

      report += `| Valor | Freq. Absoluta | Freq. Relativa | Freq. Acumulada |\n`
      report += `|-------|----------------|----------------|------------------|\n`

      stat.frequencies.slice(0, 10).forEach((freq) => {
        report += `| ${freq.value} | ${freq.absolute} | ${freq.relativePercent} | ${freq.accumulatedPercent} |\n`
      })

      if (stat.frequencies.length > 10) {
        report += `\n*Mostrando apenas os 10 primeiros valores. Total: ${stat.frequencies.length} valores únicos.*\n`
      }
      report += `\n`
    }

    // Tendências Centrais
    report += `#### Medidas de Tendência Central\n\n`
    report += `**Fórmulas:**\n`

    if (stat.centralTendency.mean !== undefined) {
      report += `- **Média (μ):** Σx / n = ${stat.centralTendency.mean.toFixed(4)}\n`
      report += `  - Soma de todos os valores dividida pela quantidade\n`
    }

    if (stat.centralTendency.median !== undefined) {
      report += `- **Mediana (Md):** ${stat.centralTendency.median.toFixed(4)}\n`
      report += `  - Valor central quando os dados estão ordenados\n`
    }

    report += `- **Moda (Mo):** ${stat.centralTendency.mode.slice(0, 3).join(", ")}\n`
    report += `  - Valor(es) mais frequente(s) (frequência: ${stat.centralTendency.modeFrequency})\n\n`

    // Separatrizes
    if (stat.separatrices) {
      report += `#### Separatrizes\n\n`
      report += `**Fórmulas:**\n`
      report += `- Percentil P: valor que deixa P% dos dados abaixo dele\n`
      report += `- Quartis dividem os dados em 4 partes iguais\n`
      report += `- Decis dividem os dados em 10 partes iguais\n\n`

      report += `**Quartis:**\n`
      report += `- Q1 (25%): ${stat.separatrices.q1?.toFixed(4)}\n`
      report += `- Q2 (50% - Mediana): ${stat.separatrices.q2?.toFixed(4)}\n`
      report += `- Q3 (75%): ${stat.separatrices.q3?.toFixed(4)}\n\n`

      report += `**Decis:**\n`
      report += `- D1 (10%): ${stat.separatrices.d1?.toFixed(4)}\n`
      report += `- D5 (50%): ${stat.separatrices.d5?.toFixed(4)}\n`
      report += `- D9 (90%): ${stat.separatrices.d9?.toFixed(4)}\n\n`
    }

    // Dispersão
    if (stat.dispersion) {
      report += `#### Medidas de Dispersão\n\n`
      report += `**Fórmulas:**\n\n`

      report += `- **Amplitude (A):** ${stat.dispersion.range?.toFixed(4)}\n`
      report += `  - Fórmula: A = Xmáx - Xmín\n`
      report += `  - Diferença entre o maior e menor valor\n\n`

      report += `- **Variância (σ²):** ${stat.dispersion.variance?.toFixed(4)}\n`
      report += `  - Fórmula: σ² = Σ(x - μ)² / n\n`
      report += `  - Média dos quadrados dos desvios em relação à média\n\n`

      report += `- **Desvio Padrão (σ):** ${stat.dispersion.stdDev?.toFixed(4)}\n`
      report += `  - Fórmula: σ = √σ²\n`
      report += `  - Raiz quadrada da variância, mesma unidade dos dados\n\n`

      report += `- **Amplitude Interquartil (IQR):** ${stat.dispersion.iqr?.toFixed(4)}\n`
      report += `  - Fórmula: IQR = Q3 - Q1\n`
      report += `  - Diferença entre o terceiro e primeiro quartil\n\n`

      report += `- **Coeficiente de Variação (CV):** ${stat.dispersion.cv?.toFixed(2)}%\n`
      report += `  - Fórmula: CV = (σ / |μ|) × 100%\n`
      report += `  - Medida relativa de dispersão, útil para comparar variáveis\n\n`
    }

    report += `---\n\n`
  })

  report += `## 4. Interpretação dos Resultados\n\n`
  report += `### Limpeza de Dados\n\n`

  const totalNulls = Array.from(statistics.values()).reduce((sum, stat) => sum + stat.nullCount, 0)
  report += `- **Total de valores faltantes:** ${totalNulls}\n`
  report += `- **Tratamento:** Valores nulos foram excluídos dos cálculos estatísticos\n\n`

  report += `### Gráficos Gerados\n\n`
  report += `Para cada variável, foram gerados os seguintes gráficos:\n\n`
  report += `- **Gráfico de Barras:** Para variáveis categóricas (nominal, ordinal, binária)\n`
  report += `  - Mostra a frequência de cada categoria\n`
  report += `- **Histograma:** Para variáveis numéricas (discreta, contínua)\n`
  report += `  - Mostra a distribuição dos valores em intervalos (bins)\n`
  report += `- **Boxplot:** Para variáveis numéricas\n`
  report += `  - Mostra quartis, mediana e outliers\n`
  report += `  - Outliers são valores fora do intervalo [Q1 - 1.5×IQR, Q3 + 1.5×IQR]\n\n`

  report += `---\n\n`
  report += `## 5. Conclusão\n\n`
  report += `Este relatório apresentou uma análise estatística completa do dataset "${fileName}", `
  report += `incluindo ${classifications.size} variáveis e ${data.length} registros. `
  report += `Todas as medidas foram calculadas seguindo as fórmulas estatísticas padrão, `
  report += `e os gráficos foram gerados automaticamente baseados no tipo de cada variável.\n\n`

  report += `**Gerado por:** Analisador de Dados  \n`
  report += `**Data de geração:** ${date} às ${time}\n`

  return report
}

export function downloadMarkdownReport(content: string, fileName: string) {
  const blob = new Blob([content], { type: "text/markdown;charset=utf-8" })
  const url = URL.createObjectURL(blob)
  const link = document.createElement("a")
  link.href = url
  link.download = `relatorio_${fileName.replace(/\.[^/.]+$/, "")}_${Date.now()}.md`
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
  URL.revokeObjectURL(url)
}

export function generateHTMLReport(
  fileName: string,
  data: any[],
  classifications: Map<string, VariableInfo>,
  statistics: Map<string, VariableStatistics>,
): string {
  const markdownContent = generateMarkdownReport(fileName, data, classifications, statistics)

  // Converter markdown básico para HTML
  let html = `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Relatório de Análise Estatística - ${fileName}</title>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
      line-height: 1.6;
      max-width: 900px;
      margin: 0 auto;
      padding: 20px;
      background: #f5f5f5;
    }
    .container {
      background: white;
      padding: 40px;
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    h1 { color: #1a1a1a; border-bottom: 3px solid #0070f3; padding-bottom: 10px; }
    h2 { color: #333; margin-top: 40px; border-bottom: 2px solid #eaeaea; padding-bottom: 8px; }
    h3 { color: #555; margin-top: 30px; }
    h4 { color: #666; margin-top: 20px; }
    code { background: #f4f4f4; padding: 2px 6px; border-radius: 3px; font-family: 'Courier New', monospace; }
    table { width: 100%; border-collapse: collapse; margin: 20px 0; }
    th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
    th { background: #f8f8f8; font-weight: 600; }
    tr:nth-child(even) { background: #fafafa; }
    strong { color: #0070f3; }
    hr { border: none; border-top: 1px solid #eaeaea; margin: 30px 0; }
    ul { padding-left: 20px; }
    li { margin: 8px 0; }
  </style>
</head>
<body>
  <div class="container">
`

  // Conversão simples de markdown para HTML
  html += markdownContent
    .replace(/^# (.*$)/gim, "<h1>$1</h1>")
    .replace(/^## (.*$)/gim, "<h2>$1</h2>")
    .replace(/^### (.*$)/gim, "<h3>$1</h3>")
    .replace(/^#### (.*$)/gim, "<h4>$4</h4>")
    .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
    .replace(/\*(.*?)\*/g, "<em>$1</em>")
    .replace(/`(.*?)`/g, "<code>$1</code>")
    .replace(/^---$/gim, "<hr>")
    .replace(/^- (.*$)/gim, "<li>$1</li>")
    .replace(/(<li>.*<\/li>)/s, "<ul>$1</ul>")
    .replace(/\n\n/g, "</p><p>")
    .replace(/^(?!<[hult])/gim, "<p>")
    .replace(/([^>])$/gim, "$1</p>")

  html += `
  </div>
</body>
</html>`

  return html
}

export function downloadHTMLReport(content: string, fileName: string) {
  const blob = new Blob([content], { type: "text/html;charset=utf-8" })
  const url = URL.createObjectURL(blob)
  const link = document.createElement("a")
  link.href = url
  link.download = `relatorio_${fileName.replace(/\.[^/.]+$/, "")}_${Date.now()}.html`
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
  URL.revokeObjectURL(url)
}
